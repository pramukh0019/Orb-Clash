import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class CircleFightGame extends JPanel implements ActionListener {
    Timer timer;
    GameLogic gameLogic;
    Random random;
    final int[] LANES = {150, 300, 450};
    JButton Lowcir, Medcir, Highcir, help;
    JComboBox<String> laneSelector;
    JFrame frame;

    public CircleFightGame() {
        this.setPreferredSize(new Dimension(800, 600));
        this.setBackground(Color.white);
        gameLogic = new GameLogic(LANES);
        random = new Random();
        timer = new Timer(16, this);  
        timer.start();
        Lowcir = new JButton("Low Circle");
        Medcir = new JButton("Medium Circle");
        Highcir = new JButton("Big Circle");
        help = new JButton("Help");
        laneSelector = new JComboBox<>(new String[]{"Lane 1", "Lane 2", "Lane 3"});

        Lowcir.addActionListener(e->new Thread(() -> handleSpawn(Lowcir, "Low")).start());
        Medcir.addActionListener(e->new Thread(() -> handleSpawn(Medcir, "Medium")).start());
        Highcir.addActionListener(e->new Thread(() -> handleSpawn(Highcir, "High")).start());
        help.addActionListener(this);
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(new JLabel("Select Lane:"));
        buttonPanel.add(laneSelector);
        buttonPanel.add(Lowcir);
        buttonPanel.add(Medcir);
        buttonPanel.add(Highcir);

        JPanel top = new JPanel();
        top.add(help);
        frame = new JFrame("Sheep Fight Game");
        frame.setLayout(new BorderLayout());
        frame.add(this, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);
        frame.add(top, BorderLayout.NORTH);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==help){
        JOptionPane.showMessageDialog(this, """
            Welcome to Circle Fight!
            - Spawn circle to fight against the opponent's circles.
            - Choose Low, Medium, or Big size circles.
            - Each circle has a speed and size based on its size:
                Low: Fast and small
                Medium: Moderate speed and size
                High: Slow and large
            - Reduce the opponent's health to zero to win!
            - Avoid letting your health drop to zero.
            -Each spawn button will spawn after 2 seconds.
        """, "Game Help", JOptionPane.INFORMATION_MESSAGE);
        return;
    }
        gameLogic.update();
        Oppcir(); 
        repaint();
        if (gameLogic.getPlayerLife() <= 0) {
            gameLogic.ourLife=0;
            Lose();
        } else if (gameLogic.getOpponentLife() <= 0) {
            gameLogic.oppLife=0;
            Win();
        }
        
    }

    private void Oppcir() {
        if (random.nextInt(100) < 0.5) {  
            String type = switch (random.nextInt(3)) {
                case 0 -> "Low";
                case 1 -> "Medium";
                default -> "High";
            };
            int randomLane = random.nextInt(LANES.length);
            gameLogic.spawnSheep(false, type, randomLane);
        }
    }

    private void Win() {
        JOptionPane.showMessageDialog(this, "Congratulations, You won!");
        frame.dispose();
    }

    private void Lose() {
        JOptionPane.showMessageDialog(this, "Game Over|, You lost.");
        frame.dispose();
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.DARK_GRAY);
        for (int lane : LANES) {
            g.drawLine(0, lane + 15, getWidth(), lane + 15);  
        }
        int playerLife = gameLogic.getPlayerLife();
        int opponentLife = gameLogic.getOpponentLife();

        // Player life bar
        g.setColor(Color.BLUE);
        g.fillRect(50, 20, playerLife * 2, 20);  
        g.setColor(Color.BLACK);
        g.drawRect(50, 20, 200, 20); 

        // Opponent life bar
        g.setColor(Color.RED);
        g.fillRect(getWidth() - 250, 20, opponentLife * 2, 20); 
        g.setColor(Color.BLACK);
        g.drawRect(getWidth() - 250, 20, 200, 20);  

        g.setColor(Color.BLACK);
        g.drawString("Player Life: " + playerLife, 50, 15);
        g.drawString("Opponent Life: " + opponentLife, getWidth() - 250, 15);
        gameLogic.draw(g);
    }
    private void handleSpawn(JButton button, String type) {
        try {
            SwingUtilities.invokeLater(() -> button.setVisible(false)); 
            gameLogic.spawnSheep(true, type, laneSelector.getSelectedIndex());
            Thread.sleep(2000); 
            SwingUtilities.invokeLater(() -> button.setVisible(true)); 
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new CircleFightGame();
    }
}

class Circle{
    int x, y;
    int speed;
    int strength;
    boolean isPlayer;

    public Circle(int x, int y, int speed, int strength, boolean isPlayer) {
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.strength = strength;
        this.isPlayer = isPlayer;
    }

    public void move() {
        if (isPlayer) {
            x += speed;
        } else {
            x -= speed;
        }
    }

    public boolean crossesOpponentSide(int screenWidth) {
        return isPlayer && x > screenWidth;
    }

    public boolean crossesPlayerSide() {
        return !isPlayer && x < 0;
    }

    public boolean isColliding(Circle other) {
        return Math.abs(this.x - other.x) < (getSize() + other.getSize()) / 2 && this.y == other.y;
    }

    public boolean isPlayer() {
        return isPlayer;
    }

    public int getStrength() {
        return strength;
    }

    public int getSize() {
        return strength * 10 + 20;     // Low: 30, Medium: 40, High: 50
    }

    public void draw(Graphics g) {
        g.setColor(isPlayer ? Color.BLUE : Color.RED);
        int size = getSize();
        g.fillOval(x, y, size, size);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}

class GameLogic {
    Circle[] ourcir;
    Circle[] oppcir;
    int ourCount; 
    int oppCount; 
    int[] lanes;

    int ourLife = 100;
    int oppLife = 100;

    static final int MAX_Size = 100; // Maximum number of sheep 

    public GameLogic(int[] lanes) {
        this.lanes = lanes;
        ourcir = new Circle[MAX_Size];
        oppcir = new Circle[MAX_Size];
        ourCount = 0;
        oppCount = 0;
    }

    public void spawnSheep(boolean isPlayer, String type, int laneIndex) {
        int speed, strength;
        switch (type) {
            case "Low" -> {
                speed = 4;
                strength = 1;
            }
            case "Medium" -> {
                speed = 3;
                strength = 2;
            }
            default -> {
                speed = 2;
                strength = 3;
            }
        }

        int laneY = lanes[laneIndex];
        Circle cir = new Circle(isPlayer ? 0 : 800, laneY, speed, strength, isPlayer);

        if (isPlayer) {
            if (ourCount < MAX_Size) {
                ourcir[ourCount++] = cir;
            }
        } else {
            if (oppCount < MAX_Size) {
                oppcir[oppCount++] = cir;
            }
        }
    }

    public void update() {
        for (int i = 0; i < ourCount; i++) {
            Circle cir = ourcir[i];
            cir.move();
            if (cir.crossesOpponentSide(800)) {
                oppLife -= cir.getStrength() * 5;
                removecir(ourcir, i, ourCount);
                ourCount--;
                i--; 
            }
        }
        for (int i = 0; i < oppCount; i++) {
            Circle cir = oppcir[i];
            cir.move();
            if (cir.crossesPlayerSide()) {
                ourLife -= cir.getStrength() * 5;
                removecir(oppcir, i, oppCount);
                oppCount--;
                i--; 
            }
        }
        resolveCollisions();
    }

    private void resolveCollisions() {
        for (int i = 0; i < ourCount; i++) {
            Circle playercir = ourcir[i];
            for (int j = 0; j < oppCount; j++) {
                Circle opponentcir = oppcir[j];
                if (playercir.isColliding(opponentcir)) {
                    if (playercir.getStrength() == opponentcir.getStrength()) {
                        
                        removecir(ourcir, i, ourCount);
                        ourCount--;
                        i--; 
                        removecir(oppcir, j, oppCount);
                        oppCount--;
                        break; 
                    } else if (playercir.getStrength() > opponentcir.getStrength()) {
                        
                        removecir(oppcir, j, oppCount);
                        oppCount--;
                        j--; 
                    } else {
                        
                        removecir(ourcir, i, ourCount);
                        ourCount--;
                        i--; 
                        break; 
                    }
                }
            }
        }
    }

    private void removecir(Circle[] cirArray, int index, int count) {
        if (index < count - 1) {
            System.arraycopy(cirArray, index + 1, cirArray, index, count - index - 1);
        }
        cirArray[count - 1] = null; // Clear the last element
    }

    public int getPlayerLife() {
        return ourLife;
    }

    public int getOpponentLife() {
        return oppLife;
    }

    public void draw(Graphics g) {
        for (int i = 0; i < ourCount; i++) {
            ourcir[i].draw(g);
        }
        for (int i = 0; i < oppCount; i++) {
            oppcir[i].draw(g);
        }
    }
}
